

class AppStyle{
  static var poppinsBold = "Poppins Bold";
  static var poppinsRegular = "Poppins Regular";
  static var poppinsLight = "Poppins Light";
}