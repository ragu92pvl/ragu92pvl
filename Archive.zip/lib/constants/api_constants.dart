

class ApiConstants{
  static var BASE_URL = "https://rvt.qads.co.in/api/";
 // static var BASE_URL = "http://192.168.1.30:8000/api/";
 // static var IMG_BASE_URL = "http://192.168.1.30:8000/";
  static var IMG_BASE_URL = "http://192.168.1.35:8000/";
  static var currency = "₹";
  static var login = "${BASE_URL}login";
  static var profile = "${BASE_URL}profile";
  static var leadCreate = "${BASE_URL}lead_create";

}