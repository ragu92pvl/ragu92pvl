package com.app.rvt.userapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
